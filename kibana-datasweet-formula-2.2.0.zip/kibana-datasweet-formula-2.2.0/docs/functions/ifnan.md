# Function ifnan

Returns an alternative value if an expression is NaN.

## Syntax
```
ifnan(value,defaultValue=0)
ifnan(serie,defaultValue=0)
```