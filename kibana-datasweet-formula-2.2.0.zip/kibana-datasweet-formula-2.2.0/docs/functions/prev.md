# Function prev

Shift a serie to left.

## Syntax
```
prev(serie)
prev(1,2,3,4,5)     // Returns [null,1,2,3,4]
```