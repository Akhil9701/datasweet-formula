# Function count

Calculate the length of a serie.

## Syntax
```
count(serie)
count(1,2,3,4,5)
```