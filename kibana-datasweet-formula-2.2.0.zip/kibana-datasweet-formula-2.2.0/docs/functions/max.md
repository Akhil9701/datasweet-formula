# Function max

Calculate the maximum of a serie.

## Syntax
```
max(serie)
max(1,2,3,4,5)
```