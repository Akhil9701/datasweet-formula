# Function min

Calculate the minimum of a serie.

## Syntax
```
min(serie)
min(1,2,3,4,5)
```