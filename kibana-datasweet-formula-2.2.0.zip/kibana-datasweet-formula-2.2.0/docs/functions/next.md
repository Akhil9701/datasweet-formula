# Function next

Shift a serie to right.

## Syntax
```
next(serie)
next(1,2,3,4,5)     // Returns [2,3,4,5,null]
```