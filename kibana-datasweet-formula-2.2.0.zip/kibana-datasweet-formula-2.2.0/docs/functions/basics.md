# Basics

## Arithmetic operators

* +
* -
* *
* /
* %
* ^

## Logical operators

* and
* or
* not

## Comparaison operators 

* < less than
* <= less than equal
* == equal
* != not equal
* &gt; greater than
* &gt;= greater than equal

## Basics maths functions

* abs
* acos
* acosh
* asin
* asinh
* atan
* atanh
* ceil
* cos
* cosh
* exp
* floor
* log (alias ln)
* log10 (alias lg)
* round
* sinh
* sqrt
* tan
* tanh
* trunc