# Function derivative

Calculate the derivative of a serie. Returns a serie.

## Syntax
```
derivative(serie)
derivative(1,2,3,4,5)        // returns [null,1,1,1,1]
```