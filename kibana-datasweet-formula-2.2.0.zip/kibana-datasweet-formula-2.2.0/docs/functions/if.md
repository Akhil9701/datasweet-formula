# Function if

Create a conditional instruction.

## Parametres

* `cond` condition. Can be a value or a serie.
* `yes` if the condition is true. Can be a value or a serie.
* `no` if the condition is false. Can be a value or a serie.

## Syntax
```
if(cond, yes, no)
```