# Function cusum

Calculate the cumulative sum of a serie. Returns a serie.

## Syntax
```
cusum(serie)
cusum(1,2,3,4,5)        // returns [1,3,6,10,15]
```