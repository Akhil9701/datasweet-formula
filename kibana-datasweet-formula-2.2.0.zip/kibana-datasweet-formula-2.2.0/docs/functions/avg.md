# Function avg

Calculate the average value of a serie.

## Syntax
```
avg(serie)
avg(1,2,3,4,5)
```