# Function percentile

Calculate the n-th percentile of a serie.

## Parameters

* `serie`
* `n` The requested percentile, e.g. 50 (median) or 90.

## Syntax
```
percentile(serie, n)
```