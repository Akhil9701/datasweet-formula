# Installation

Copy the last installation url for your version of Kibana from the [repository releases](https://github.com/datasweet-fr/kibana-datasweet-formula/releases/latest).
```
./bin/kibana-plugin install  https://github.com/datasweet-fr/kibana-datasweet-formula/releases/download/version_name/datasweet_formula-X.X.X_kibana-major.minor.patch.zip
```

This plugin is supported by : 

* Kibana 6.x
* Kibana >= 5.6