# About

We are Datasweet, a french startup providing full service (big) data solutions. We tweaked Kibana to fit our needs. We might release more features to the community in the future, but we are shy guys, we need some encouragement ! Make some noise if Datasweet Formula is useful to you !

* [www.datasweet.fr](http://www.datasweet.fr)
* [GitHub](https://github.com/datasweet-fr/kibana-datasweet-formula/)
